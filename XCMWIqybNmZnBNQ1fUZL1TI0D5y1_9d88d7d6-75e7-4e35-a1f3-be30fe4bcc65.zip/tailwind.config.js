
const colors = require("tailwindcss/colors");
const theme = require("tailwindcss/defaultTheme");

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    fontFamily: {
      display: ["Pally", "sans-serif"],
      body: ["Pally", "sans-serif"],
    },
    extend: {
      colors: {
        primary: colors.violet
      },
      borderRadius: {
        primary: theme.borderRadius.full,
      },
    },
  },
  plugins: [],
};
