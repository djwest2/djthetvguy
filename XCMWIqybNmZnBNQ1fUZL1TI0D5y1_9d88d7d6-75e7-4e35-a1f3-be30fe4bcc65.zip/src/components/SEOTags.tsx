import { content, images } from "@/config";
import Head from "next/head";

export function SEOTags() {
  return (
    <Head>
      <title>{content.seoTitle}</title>
      <meta name="description" content={content.shortDescription} />
      <meta name="keywords" content={content.seoKeywords} />

      <meta property="og:type" content="website" />
      <meta property="og:title" content={content.seoTitle} />
      <meta property="og:description" content={content.shortDescription} />
      {images.socialMediaImage && (
        <meta property="og:image" content={images.socialMediaImage} />
      )}

      <meta name="twitter:title" content={content.seoTitle} />
      <meta name="twitter:description" content={content.shortDescription} />
      {images.socialMediaImage && (
        <>
          <meta name="twitter:card" content="summary_large_image" />
          <meta property="twitter:image" content={images.socialMediaImage} />
        </>
      )}
    </Head>
  );
}
