
export const content = {
  "shortProductDescription": "Get access to thousands of live TV channels, movies, TV series, and more with the DJ THE TV GUY subscription. Experience entertainment like never before.",
  "featureDescription": "With DJ THE TV GUY, you'll have access to 8000 live TV channels, a comprehensive TV guide, 30000 movies on demand, and 5500 TV series. Never miss a show or a game again - we've got you covered.",
  "companyName": "DJ THE TV GUY",
  "shortDescription": "Welcome to DJ THE TV GUY! We provide top-quality live TV, movies, TV series, PPV and sports events, all in one convenient package. Say goodbye to expensive cable bills and limited options - with DJ THE TV GUY, you get it all at an affordable price.",
  "seoTitle": "DJ THE TV GUY - Unlimited entertainment at an affordable price",
  "seoKeywords": "TV, entertainment, live channels, movies, series",
  "marketingTitle": "DJ THE TV GUY - Your One-Stop Entertainment Solution",
  "productName": "DJ THE TV GUY Subscription",
  "featureTitle": "Endless Entertainment",
  "features": [
    {
      "name": "Unlimited Connections",
      "description": "Whether you need 1 connection or 5, we've got flexible plans to accommodate your needs. Share your subscription with friends and family, or enjoy multi-device access all to yourself - it's your choice."
    },
    {
      "name": "No IP Lock",
      "description": "Don't be tied down to a specific location. With DJ THE TV GUY, you can use our service anywhere - at home, on vacation, or even at a friend's house."
    },
    {
      "name": "Support for PPV and Sports Events",
      "description": "Catch all the action with our support for pay-per-view events and sports. Don't miss out on the latest matches, fights, and exclusive events."
    }
  ],
  "ctaTitle": "Start your entertainment journey today",
  "featureAction": "Experience unlimited entertainment",
  "pricingFeatures": [
    "8000 Live TV channels",
    "30000 Movies on demand",
    "5500 TV series",
    "PPV and Sports Events"
  ],
  "productPrice": 15
};

export const images = {
  mainScreenshot:
    "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2370&q=80",
  productScreenshot:
    "https://images.unsplash.com/photo-1620987278429-ab178d6eb547?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1925&q=800",
  socialMediaImage:
    "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2370&q=80",
  logo: "/logo.svg",
};

// The price of your product in USD
export const pricing = {
  price: 299,
};

// Remove any social media accounts you don't want to include
export const socialMediaLinks = {
  twitter: "https://twitter.com/",
  facebook: "https://facebook.com/",
  instagram: "https://instagram.com/",
  github: "https://github.com/",
  youtube: "https://youtube.com/",
}; 
